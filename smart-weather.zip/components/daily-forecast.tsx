import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { DailyForecast } from "@/types/weather"
import { Thermometer, Wind, Umbrella } from "lucide-react"
import Image from "next/image"

interface DailyForecastProps {
  forecast: DailyForecast[]
}

export function DailyForecastComponent({ forecast }: DailyForecastProps) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("en-US", { weekday: "short", month: "short", day: "numeric" }).format(date)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>7-Day Forecast</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-4">
          {forecast.map((day, index) => (
            <Card key={index} className="overflow-hidden">
              <CardHeader className="p-3 pb-0">
                <CardTitle className="text-sm font-medium">{formatDate(day.date)}</CardTitle>
              </CardHeader>
              <CardContent className="p-3">
                <div className="flex flex-col items-center">
                  <div className="mb-2">
                    {day.day.condition.icon && (
                      <Image
                        src={`https:${day.day.condition.icon}`}
                        alt={day.day.condition.text}
                        width={48}
                        height={48}
                      />
                    )}
                  </div>
                  <div className="text-sm font-medium capitalize mb-2">{day.day.condition.text}</div>
                  <div className="flex items-center gap-1 mb-2">
                    <Thermometer className="h-4 w-4 text-red-500" />
                    <span className="text-xs">
                      {Math.round(day.day.maxtemp_c)}°C / {Math.round(day.day.maxtemp_f)}°F
                    </span>
                  </div>
                  <div className="flex items-center gap-1 mb-2">
                    <Thermometer className="h-4 w-4 text-blue-500" />
                    <span className="text-xs">
                      {Math.round(day.day.mintemp_c)}°C / {Math.round(day.day.mintemp_f)}°F
                    </span>
                  </div>
                  <div className="flex items-center gap-1 mb-2">
                    <Umbrella className="h-4 w-4 text-blue-500" />
                    <span className="text-xs">{day.day.daily_chance_of_rain}%</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Wind className="h-4 w-4 text-gray-500" />
                    <span className="text-xs">{Math.round(day.day.maxwind_kph)} km/h</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
