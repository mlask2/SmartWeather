import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:smart_weather/providers/weather_provider.dart';
import 'package:smart_weather/widgets/current_weather_widget.dart';
import 'package:smart_weather/widgets/daily_forecast_widget.dart';
import 'package:smart_weather/widgets/hourly_forecast_widget.dart';
import 'package:smart_weather/widgets/search_bar_widget.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'SmartWeather',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: Consumer<WeatherProvider>(
        builder: (context, weatherProvider, child) {
          return SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Search Bar
                  WeatherSearchBar(
                    onCitySearch: (city) => weatherProvider.fetchWeatherByCity(city),
                    onLocationSearch: () => weatherProvider.fetchWeatherByLocation(),
                  ),
                  
                  const SizedBox(height: 16),
                  
                  // API Key Error Message
                  if (weatherProvider.isApiKeyError)
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.red.shade100,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.red),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.error_outline, color: Colors.red.shade700),
                              const SizedBox(width: 8),
                              Text(
                                'API Key Error',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: Colors.red.shade700,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'There\'s an issue with the Weather API key. Please make sure you\'ve set a valid WEATHER_API_KEY in your .env file. The app is currently showing mock data.',
                            style: TextStyle(color: Colors.red.shade700),
                          ),
                        ],
                      ),
                    ),
                  
                  const SizedBox(height: 16),
                  
                  // Loading Indicator or Weather Data
                  if (weatherProvider.isLoading)
                    _buildLoadingIndicators()
                  else if (weatherProvider.weatherData != null)
                    _buildWeatherContent(context, weatherProvider),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildLoadingIndicators() {
    return Column(
      children: [
        // Current Weather Skeleton
        Container(
          height: 200,
          decoration: BoxDecoration(
            color: Colors.grey.shade200,
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Center(child: CircularProgressIndicator()),
        ),
        const SizedBox(height: 16),
        
        // Daily Forecast Skeleton
        Container(
          height: 300,
          decoration: BoxDecoration(
            color: Colors.grey.shade200,
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Center(child: CircularProgressIndicator()),
        ),
        const SizedBox(height: 16),
        
        // Hourly Forecast Skeleton
        Container(
          height: 150,
          decoration: BoxDecoration(
            color: Colors.grey.shade200,
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Center(child: CircularProgressIndicator()),
        ),
      ],
    );
  }

  Widget _buildWeatherContent(BuildContext context, WeatherProvider weatherProvider) {
    final weatherData = weatherProvider.weatherData!;
    
    return Column(
      children: [
        // Current Weather
        CurrentWeatherWidget(data: weatherData),
        const SizedBox(height: 16),
        
        // Daily Forecast
        DailyForecastWidget(forecast: weatherData.forecast.forecastday),
        const SizedBox(height: 16),
        
        // Hourly Forecast
        HourlyForecastWidget(forecast: weatherData.hourly),
      ],
    );
  }
}
