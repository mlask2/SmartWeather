import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:smart_weather/models/weather_model.dart';
import 'package:smart_weather/services/weather_service.dart';

class WeatherProvider extends ChangeNotifier {
  final WeatherService _weatherService = WeatherService();
  
  WeatherModel? _weatherData;
  bool _isLoading = false;
  String? _error;
  bool _isApiKeyError = false;

  WeatherModel? get weatherData => _weatherData;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isApiKeyError => _isApiKeyError;

  WeatherProvider() {
    // Load default city on startup
    fetchWeatherByCity('London');
  }

  Future<void> fetchWeatherByCity(String city) async {
    _setLoading(true);
    _clearError();
    
    try {
      final data = await _weatherService.getWeatherByCity(city);
      _weatherData = data;
      _setLoading(false);
    } catch (e) {
      _handleError(e.toString());
      
      // If it's an API key error, use mock data
      if (_isApiKeyError) {
        _weatherData = WeatherModel.mock(city);
      }
    }
  }

  Future<void> fetchWeatherByLocation() async {
    _setLoading(true);
    _clearError();
    
    try {
      // Check location permission
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          throw Exception('Location permission denied');
        }
      }
      
      if (permission == LocationPermission.deniedForever) {
        throw Exception('Location permission permanently denied');
      }
      
      // Get current position
      final position = await Geolocator.getCurrentPosition();
      
      final data = await _weatherService.getWeatherByCoordinates(
        position.latitude, 
        position.longitude
      );
      
      _weatherData = data;
      _setLoading(false);
    } catch (e) {
      _handleError(e.toString());
      
      // If it's an API key error, use mock data
      if (_isApiKeyError) {
        _weatherData = WeatherModel.mock('Current Location');
      }
    }
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _clearError() {
    _error = null;
    _isApiKeyError = false;
    notifyListeners();
  }

  void _handleError(String errorMessage) {
    _error = errorMessage;
    
    // Check if it's an API key error
    if (errorMessage.contains('API key')) {
      _isApiKeyError = true;
    }
    
    _setLoading(false);
  }
}
