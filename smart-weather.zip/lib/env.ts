// This file ensures we can access environment variables correctly
export const getApiKey = () => {
  // Get the API key from environment variables
  const apiKey = process.env.OPENWEATHER_API_KEY

  if (!apiKey) {
    console.error("Weather API key is not defined in environment variables")
    // Instead of throwing an error, return a placeholder message
    return "API_KEY_MISSING"
  }

  return apiKey
}

// Check if the API key is valid (not just present)
export const isApiKeyValid = () => {
  const apiKey = getApiKey()
  return apiKey !== "API_KEY_MISSING" && apiKey.length > 10
}
