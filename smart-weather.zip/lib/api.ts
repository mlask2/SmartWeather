import { getApiKey, isApiKeyValid } from "./env"
import type { WeatherData, LocationData } from "@/types/weather"

export async function fetchWeatherByCity(city: string): Promise<WeatherData> {
  try {
    console.log(`Fetching weather for city: ${city}`)

    // Check if API key is valid before making any requests
    if (!isApiKeyValid()) {
      throw new Error("API key is missing or invalid")
    }

    // Get API key from environment
    const API_KEY = getApiKey()

    // WeatherAPI can directly search by city name
    return fetchWeatherData(city, API_KEY)
  } catch (error) {
    console.error("Error fetching weather by city:", error)
    throw error
  }
}

export async function fetchWeatherByCoords(
  lat: number,
  lon: number,
  locationData?: LocationData,
): Promise<WeatherData> {
  try {
    console.log(`Fetching weather for coordinates: ${lat}, ${lon}`)

    // Check if API key is valid before making any requests
    if (!isApiKeyValid()) {
      throw new Error("API key is missing or invalid")
    }

    // Get API key from environment
    const API_KEY = getApiKey()

    // WeatherAPI can search by coordinates in format "lat,lon"
    const query = `${lat},${lon}`
    return fetchWeatherData(query, API_KEY)
  } catch (error) {
    console.error("Error fetching weather by coordinates:", error)
    throw error
  }
}

async function fetchWeatherData(query: string, apiKey: string): Promise<WeatherData> {
  // WeatherAPI forecast endpoint with 7 days and hourly data
  const url = `https://api.weatherapi.com/v1/forecast.json?key=${apiKey}&q=${encodeURIComponent(
    query,
  )}&days=7&aqi=no&alerts=no`
  console.log(`Weather API URL: ${url.replace(apiKey, "[API_KEY]")}`)

  const response = await fetch(url)

  if (!response.ok) {
    const errorText = await response.text()
    console.error(`Weather API error: ${response.status} - ${errorText}`)

    if (response.status === 401 || response.status === 403) {
      throw new Error("Invalid API key. Please check your Weather API key.")
    }

    throw new Error(`Failed to fetch weather data: ${response.status}`)
  }

  const data = await response.json()
  console.log("Weather data received")

  // Transform the WeatherAPI data to match our WeatherData interface
  const weatherData: WeatherData = {
    location: {
      name: data.location.name,
      country: data.location.country,
      lat: data.location.lat,
      lon: data.location.lon,
    },
    current: {
      temp_c: data.current.temp_c,
      temp_f: data.current.temp_f,
      condition: {
        text: data.current.condition.text,
        icon: data.current.condition.icon,
        code: data.current.condition.code,
      },
      wind_kph: data.current.wind_kph,
      wind_mph: data.current.wind_mph,
      humidity: data.current.humidity,
      precip_mm: data.current.precip_mm,
      precip_in: data.current.precip_in,
      feelslike_c: data.current.feelslike_c,
      feelslike_f: data.current.feelslike_f,
      uv: data.current.uv,
    },
    forecast: {
      forecastday: data.forecast.forecastday.map((day: any) => ({
        date: day.date,
        day: {
          maxtemp_c: day.day.maxtemp_c,
          maxtemp_f: day.day.maxtemp_f,
          mintemp_c: day.day.mintemp_c,
          mintemp_f: day.day.mintemp_f,
          avgtemp_c: day.day.avgtemp_c,
          avgtemp_f: day.day.avgtemp_f,
          condition: {
            text: day.day.condition.text,
            icon: day.day.condition.icon,
            code: day.day.condition.code,
          },
          daily_chance_of_rain: day.day.daily_chance_of_rain,
          daily_chance_of_snow: day.day.daily_chance_of_snow,
          maxwind_kph: day.day.maxwind_kph,
          maxwind_mph: day.day.maxwind_mph,
          totalprecip_mm: day.day.totalprecip_mm,
          totalprecip_in: day.day.totalprecip_in,
        },
      })),
    },
    hourly: data.forecast.forecastday[0].hour.map((hour: any) => ({
      time: hour.time,
      temp_c: hour.temp_c,
      temp_f: hour.temp_f,
      condition: {
        text: hour.condition.text,
        icon: hour.condition.icon,
        code: hour.condition.code,
      },
      wind_kph: hour.wind_kph,
      wind_mph: hour.wind_mph,
      chance_of_rain: hour.chance_of_rain,
      chance_of_snow: hour.chance_of_snow,
    })),
  }

  return weatherData
}
