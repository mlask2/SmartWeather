import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:smart_weather/models/weather_model.dart';

class HourlyForecastWidget extends StatelessWidget {
  final List<HourlyForecastModel> forecast;

  const HourlyForecastWidget({
    super.key,
    required this.forecast,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '24-Hour Forecast',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 140,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: forecast.length,
                itemBuilder: (context, index) {
                  return _buildHourlyForecastItem(context, forecast[index]);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHourlyForecastItem(BuildContext context, HourlyForecastModel hour) {
    final theme = Theme.of(context);
    final time = DateTime.parse(hour.time);
    final formattedTime = DateFormat('ha').format(time);
    
    return Container(
      width: 80,
      margin: const EdgeInsets.only(right: 8),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            formattedTime,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          Image.network(
            'https:${hour.condition.icon}',
            width: 40,
            height: 40,
            errorBuilder: (context, error, stackTrace) {
              return const Icon(Icons.image_not_supported, size: 40);
            },
          ),
          Text(
            '${hour.tempC.round()}°C',
            style: theme.textTheme.bodyMedium,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.umbrella,
                size: 12,
                color: Colors.blue,
              ),
              const SizedBox(width: 2),
              Text(
                '${hour.chanceOfRain}%',
                style: theme.textTheme.bodySmall,
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                Icons.air,
                size: 12,
                color: Colors.grey,
              ),
              const SizedBox(width: 2),
              Text(
                '${hour.windKph.round()} km/h',
                style: theme.textTheme.bodySmall,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
