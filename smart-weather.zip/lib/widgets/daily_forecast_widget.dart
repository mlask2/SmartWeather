import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:smart_weather/models/weather_model.dart';

class DailyForecastWidget extends StatelessWidget {
  final List<DailyForecastModel> forecast;

  const DailyForecastWidget({
    super.key,
    required this.forecast,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '7-Day Forecast',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 220,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: forecast.length,
                itemBuilder: (context, index) {
                  return _buildDailyForecastItem(context, forecast[index]);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDailyForecastItem(BuildContext context, DailyForecastModel day) {
    final theme = Theme.of(context);
    final date = DateTime.parse(day.date);
    final formattedDate = DateFormat('EEE, MMM d').format(date);
    
    return Container(
      width: 140,
      margin: const EdgeInsets.only(right: 12),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceVariant.withOpacity(0.3),
        borderRadius: BorderRadius.circular(12),
      ),
      padding: const EdgeInsets.all(12),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            formattedDate,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.bold,
            ),
            textAlign: TextAlign.center,
          ),
          Image.network(
            'https:${day.day.condition.icon}',
            width: 48,
            height: 48,
            errorBuilder: (context, error, stackTrace) {
              return const Icon(Icons.image_not_supported, size: 48);
            },
          ),
          Text(
            day.day.condition.text,
            style: theme.textTheme.bodySmall,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          _buildForecastDetail(
            context,
            Icons.thermostat,
            Colors.red,
            'High: ${day.day.maxtempC.round()}°C / ${day.day.maxtempF.round()}°F',
          ),
          _buildForecastDetail(
            context,
            Icons.thermostat,
            Colors.blue,
            'Low: ${day.day.mintempC.round()}°C / ${day.day.mintempF.round()}°F',
          ),
          _buildForecastDetail(
            context,
            Icons.umbrella,
            Colors.blue,
            'Rain: ${day.day.dailyChanceOfRain}%',
          ),
          _buildForecastDetail(
            context,
            Icons.air,
            Colors.grey,
            'Wind: ${day.day.maxwindKph.round()} km/h',
          ),
        ],
      ),
    );
  }

  Widget _buildForecastDetail(
    BuildContext context,
    IconData icon,
    Color color,
    String text,
  ) {
    return Row(
      children: [
        Icon(
          icon,
          size: 14,
          color: color,
        ),
        const SizedBox(width: 4),
        Expanded(
          child: Text(
            text,
            style: Theme.of(context).textTheme.bodySmall,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }
}
