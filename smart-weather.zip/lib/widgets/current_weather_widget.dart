import 'package:flutter/material.dart';
import 'package:smart_weather/models/weather_model.dart';

class CurrentWeatherWidget extends StatelessWidget {
  final WeatherModel data;

  const CurrentWeatherWidget({
    super.key,
    required this.data,
  });

  @override
  Widget build(BuildContext context) {
    final current = data.current;
    final location = data.location;
    final theme = Theme.of(context);
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    '${location.name}, ${location.country}',
                    style: theme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Image.network(
                  'https:${current.condition.icon}',
                  width: 64,
                  height: 64,
                  errorBuilder: (context, error, stackTrace) {
                    return const Icon(Icons.image_not_supported, size: 64);
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Left column - Temperature and condition
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${current.tempC.round()}°C / ${current.tempF.round()}°F',
                        style: theme.textTheme.headlineMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        current.condition.text,
                        style: theme.textTheme.titleMedium?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Feels like: ${current.feelslikeC.round()}°C / ${current.feelslikeF.round()}°F',
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                
                // Right column - Weather details
                Expanded(
                  child: Column(
                    children: [
                      _buildWeatherDetailRow(
                        context,
                        Icons.air,
                        'Wind',
                        '${current.windKph.round()} km/h / ${current.windMph.round()} mph',
                      ),
                      const SizedBox(height: 8),
                      _buildWeatherDetailRow(
                        context,
                        Icons.water_drop,
                        'Humidity',
                        '${current.humidity}%',
                      ),
                      const SizedBox(height: 8),
                      _buildWeatherDetailRow(
                        context,
                        Icons.umbrella,
                        'Precipitation',
                        '${current.precipMm} mm / ${current.precipIn.toStringAsFixed(2)} in',
                      ),
                      const SizedBox(height: 8),
                      _buildWeatherDetailRow(
                        context,
                        Icons.wb_sunny,
                        'UV Index',
                        '${current.uv}',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWeatherDetailRow(
    BuildContext context,
    IconData icon,
    String label,
    String value,
  ) {
    final theme = Theme.of(context);
    
    return Row(
      children: [
        Icon(
          icon,
          size: 20,
          color: theme.colorScheme.primary,
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: theme.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                value,
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
