"use client"

import { useState, useEffect } from "react"
import { SearchBar } from "@/components/search-bar"
import { CurrentWeather } from "@/components/current-weather"
import { DailyForecastComponent } from "@/components/daily-forecast"
import { HourlyForecastComponent } from "@/components/hourly-forecast"
import type { WeatherData } from "@/types/weather"
import { Card, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { useToast } from "@/components/ui/use-toast"
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert"
import { ExclamationTriangleIcon } from "@radix-ui/react-icons"

export default function Home() {
  const [weatherData, setWeatherData] = useState<WeatherData | null>(null)
  const [loading, setLoading] = useState(false)
  const [apiKeyError, setApiKeyError] = useState(false)
  const { toast } = useToast()

  const fetchWeatherByCity = async (city: string) => {
    setLoading(true)
    setApiKeyError(false)
    try {
      console.log(`Fetching weather for city: ${city}`)
      const response = await fetch(`/api/weather?city=${encodeURIComponent(city)}`)

      if (!response.ok) {
        const errorData = await response.json()
        console.error("Error response:", errorData)

        // Check if this is an API key error
        if (
          errorData.error &&
          (errorData.error.includes("API key") || response.status === 401 || errorData.error.includes("401"))
        ) {
          setApiKeyError(true)
          throw new Error("Invalid API key. Please check your Weather API key.")
        }

        throw new Error(errorData.error || "Failed to fetch weather data")
      }

      const data = await response.json()
      setWeatherData(data)
    } catch (error: any) {
      console.error("Error fetching weather data:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to fetch weather data. Please try again.",
        variant: "destructive",
      })

      // If we have an API key error, let's use mock data
      if (apiKeyError) {
        setWeatherData(getMockWeatherData(city))
      }
    } finally {
      setLoading(false)
    }
  }

  const fetchWeatherByCoords = async (lat: number, lon: number) => {
    setLoading(true)
    setApiKeyError(false)
    try {
      console.log(`Fetching weather for coordinates: ${lat}, ${lon}`)
      const response = await fetch(`/api/weather?lat=${lat}&lon=${lon}`)

      if (!response.ok) {
        const errorData = await response.json()
        console.error("Error response:", errorData)

        // Check if this is an API key error
        if (
          errorData.error &&
          (errorData.error.includes("API key") || response.status === 401 || errorData.error.includes("401"))
        ) {
          setApiKeyError(true)
          throw new Error("Invalid API key. Please check your Weather API key.")
        }

        throw new Error(errorData.error || "Failed to fetch weather data")
      }

      const data = await response.json()
      setWeatherData(data)
    } catch (error: any) {
      console.error("Error fetching weather data:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to fetch weather data. Please try again.",
        variant: "destructive",
      })

      // If we have an API key error, let's use mock data
      if (apiKeyError) {
        setWeatherData(getMockWeatherData("Current Location"))
      }
    } finally {
      setLoading(false)
    }
  }

  // Default to London on initial load
  useEffect(() => {
    fetchWeatherByCity("London")
  }, [])

  return (
    <main className="container mx-auto py-8 px-4">
      <div className="flex flex-col items-center space-y-8">
        <h1 className="text-3xl font-bold">SmartWeather</h1>

        <SearchBar onSearch={fetchWeatherByCity} onLocationSearch={fetchWeatherByCoords} />

        {apiKeyError && (
          <Alert variant="destructive" className="w-full max-w-3xl">
            <ExclamationTriangleIcon className="h-4 w-4" />
            <AlertTitle>API Key Error</AlertTitle>
            <AlertDescription>
              There's an issue with the Weather API key. Please make sure you've set a valid OPENWEATHER_API_KEY
              environment variable. The app is currently showing mock data.
            </AlertDescription>
          </Alert>
        )}

        {loading ? (
          <div className="w-full space-y-6">
            <Card>
              <CardContent className="p-6">
                <Skeleton className="h-[200px] w-full" />
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <Skeleton className="h-[300px] w-full" />
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <Skeleton className="h-[150px] w-full" />
              </CardContent>
            </Card>
          </div>
        ) : weatherData ? (
          <div className="w-full space-y-6">
            <CurrentWeather data={weatherData} />
            <DailyForecastComponent forecast={weatherData.forecast.forecastday} />
            <HourlyForecastComponent forecast={weatherData.hourly} />
          </div>
        ) : null}
      </div>
    </main>
  )
}

// Function to generate mock weather data for demonstration purposes
function getMockWeatherData(locationName: string): WeatherData {
  return {
    location: {
      name: locationName,
      country: "Demo Country",
      lat: 51.5074,
      lon: -0.1278,
    },
    current: {
      temp_c: 22,
      temp_f: 71.6,
      condition: {
        text: "Partly cloudy",
        icon: "//cdn.weatherapi.com/weather/64x64/day/116.png",
        code: 1003,
      },
      wind_kph: 15,
      wind_mph: 9.3,
      humidity: 65,
      precip_mm: 0,
      precip_in: 0,
      feelslike_c: 22,
      feelslike_f: 71.6,
      uv: 4,
    },
    forecast: {
      forecastday: Array.from({ length: 7 }, (_, i) => ({
        date: new Date(Date.now() + i * 86400000).toISOString().split("T")[0],
        day: {
          maxtemp_c: 22 + Math.floor(Math.random() * 5),
          maxtemp_f: 71.6 + Math.floor(Math.random() * 9),
          mintemp_c: 15 + Math.floor(Math.random() * 3),
          mintemp_f: 59 + Math.floor(Math.random() * 5),
          avgtemp_c: 18 + Math.floor(Math.random() * 4),
          avgtemp_f: 64.4 + Math.floor(Math.random() * 7),
          condition: {
            text: ["Sunny", "Partly cloudy", "Cloudy", "Light rain"][Math.floor(Math.random() * 4)],
            icon: [
              "//cdn.weatherapi.com/weather/64x64/day/113.png",
              "//cdn.weatherapi.com/weather/64x64/day/116.png",
              "//cdn.weatherapi.com/weather/64x64/day/119.png",
              "//cdn.weatherapi.com/weather/64x64/day/296.png",
            ][Math.floor(Math.random() * 4)],
            code: [1000, 1003, 1006, 1183][Math.floor(Math.random() * 4)],
          },
          daily_chance_of_rain: Math.floor(Math.random() * 50),
          daily_chance_of_snow: 0,
          maxwind_kph: 10 + Math.floor(Math.random() * 20),
          maxwind_mph: 6 + Math.floor(Math.random() * 12),
          totalprecip_mm: Math.random() * 5,
          totalprecip_in: Math.random() * 0.2,
        },
      })),
    },
    hourly: Array.from({ length: 24 }, (_, i) => {
      const hour = new Date()
      hour.setHours(hour.getHours() + i)
      return {
        time: hour.toISOString(),
        temp_c: 18 + Math.floor(Math.random() * 8),
        temp_f: 64.4 + Math.floor(Math.random() * 14),
        condition: {
          text: ["Clear", "Partly cloudy", "Cloudy", "Light rain"][Math.floor(Math.random() * 4)],
          icon: [
            "//cdn.weatherapi.com/weather/64x64/night/113.png",
            "//cdn.weatherapi.com/weather/64x64/night/116.png",
            "//cdn.weatherapi.com/weather/64x64/night/119.png",
            "//cdn.weatherapi.com/weather/64x64/night/296.png",
          ][Math.floor(Math.random() * 4)],
          code: [1000, 1003, 1006, 1183][Math.floor(Math.random() * 4)],
        },
        wind_kph: 5 + Math.floor(Math.random() * 15),
        wind_mph: 3 + Math.floor(Math.random() * 9),
        chance_of_rain: Math.floor(Math.random() * 40),
        chance_of_snow: 0,
      }
    }),
  }
}
