import { type NextRequest, NextResponse } from "next/server"
import { fetchWeatherByCity, fetchWeatherByCoords } from "@/lib/api"
import { isApiKeyValid } from "@/lib/env"

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const city = searchParams.get("city")
  const lat = searchParams.get("lat")
  const lon = searchParams.get("lon")

  // Check if API key is valid before making any requests
  if (!isApiKeyValid()) {
    console.error("API key is missing or invalid")
    return NextResponse.json(
      {
        error: "API key is missing or invalid. Please set a valid OPENWEATHER_API_KEY environment variable.",
      },
      { status: 500 },
    )
  }

  try {
    let weatherData

    if (city) {
      console.log(`API route: Fetching weather for city: ${city}`)
      weatherData = await fetchWeatherByCity(city)
    } else if (lat && lon) {
      console.log(`API route: Fetching weather for coordinates: ${lat}, ${lon}`)
      weatherData = await fetchWeatherByCoords(Number.parseFloat(lat), Number.parseFloat(lon))
    } else {
      console.log("API route: Missing required parameters")
      return NextResponse.json({ error: "Either city or lat/lon parameters are required" }, { status: 400 })
    }

    return NextResponse.json(weatherData)
  } catch (error: any) {
    console.error("Error in weather API route:", error)
    return NextResponse.json({ error: error.message || "Failed to fetch weather data" }, { status: 500 })
  }
}
