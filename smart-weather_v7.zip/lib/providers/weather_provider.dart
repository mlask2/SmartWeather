import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:smart_weather/models/weather_model.dart';
import 'package:smart_weather/services/weather_service.dart';

class WeatherProvider extends ChangeNotifier {
  final WeatherService _weatherService = WeatherService();
  
  WeatherModel? _weatherData;
  bool _isLoading = false;
  String? _error;
  bool _isApiKeyError = false;
  Timer? _refreshTimer;
  DateTime? _lastUpdated;
  String _lastQuery = 'London';
  bool _isLocationQuery = false;
  double? _lastLat;
  double? _lastLon;

  WeatherModel? get weatherData => _weatherData;
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get isApiKeyError => _isApiKeyError;
  DateTime? get lastUpdated => _lastUpdated;

  WeatherProvider() {
    // Load default city on startup
    fetchWeatherByCity('London');
    
    // Set up auto-refresh timer (every 10 minutes)
    _startAutoRefresh();
  }

  void _startAutoRefresh() {
    // Cancel any existing timer
    _refreshTimer?.cancel();
    
    // Create a new timer that refreshes data every 10 minutes
    _refreshTimer = Timer.periodic(const Duration(minutes: 10), (_) {
      _refreshWeatherData();
    });
  }

  void _refreshWeatherData() {
    if (_isLocationQuery && _lastLat != null && _lastLon != null) {
      fetchWeatherByCoordinates(_lastLat!, _lastLon!, silent: true);
    } else if (_lastQuery.isNotEmpty) {
      fetchWeatherByCity(_lastQuery, silent: true);
    }
  }

  Future<void> fetchWeatherByCity(String city, {bool silent = false}) async {
    if (!silent) _setLoading(true);
    _clearError();
    _lastQuery = city;
    _isLocationQuery = false;
    
    try {
      final data = await _weatherService.getWeatherByCity(city);
      _weatherData = data;
      _lastUpdated = DateTime.now();
      if (!silent) _setLoading(false);
      notifyListeners();
    } catch (e) {
      _handleError(e.toString());
      
      // If it's an API key error, use mock data
      if (_isApiKeyError) {
        _weatherData = WeatherModel.mock(city);
        _lastUpdated = DateTime.now();
        notifyListeners();
      }
    }
  }

  Future<void> fetchWeatherByCoordinates(double lat, double lon, {bool silent = false}) async {
    if (!silent) _setLoading(true);
    _clearError();
    _isLocationQuery = true;
    _lastLat = lat;
    _lastLon = lon;
    
    try {
      final data = await _weatherService.getWeatherByCoordinates(lat, lon);
      _weatherData = data;
      _lastUpdated = DateTime.now();
      if (!silent) _setLoading(false);
      notifyListeners();
    } catch (e) {
      _handleError(e.toString());
      
      // If it's an API key error, use mock data
      if (_isApiKeyError) {
        _weatherData = WeatherModel.mock('Current Location');
        _lastUpdated = DateTime.now();
        notifyListeners();
      }
    }
  }

  Future<void> fetchWeatherByLocation({bool silent = false}) async {
    if (!silent) _setLoading(true);
    _clearError();
    
    try {
      // Check location permission
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          throw Exception('Location permission denied');
        }
      }
      
      if (permission == LocationPermission.deniedForever) {
        throw Exception('Location permission permanently denied');
      }
      
      // Get current position
      final position = await Geolocator.getCurrentPosition();
      
      _lastLat = position.latitude;
      _lastLon = position.longitude;
      _isLocationQuery = true;
      
      final data = await _weatherService.getWeatherByCoordinates(
        position.latitude, 
        position.longitude
      );
      
      _weatherData = data;
      _lastUpdated = DateTime.now();
      if (!silent) _setLoading(false);
      notifyListeners();
    } catch (e) {
      _handleError(e.toString());
      
      // If it's an API key error, use mock data
      if (_isApiKeyError) {
        _weatherData = WeatherModel.mock('Current Location');
        _lastUpdated = DateTime.now();
        notifyListeners();
      }
    }
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _clearError() {
    _error = null;
    _isApiKeyError = false;
    notifyListeners();
  }

  void _handleError(String errorMessage) {
    _error = errorMessage;
    
    // Check if it's an API key error
    if (errorMessage.contains('API key')) {
      _isApiKeyError = true;
    }
    
    _setLoading(false);
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }
}
