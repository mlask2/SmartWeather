import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeProvider extends ChangeNotifier {
  ThemeMode _themeMode = ThemeMode.system;
  bool _isLargeText = false;
  bool _isHighContrast = false;
  bool _useCelsius = true; // Default to Celsius

  ThemeMode get themeMode => _themeMode;
  bool get isLargeText => _isLargeText;
  bool get isHighContrast => _isHighContrast;
  bool get useCelsius => _useCelsius;

  // Constructor loads saved preferences
  ThemeProvider() {
    _loadPreferences();
  }

  // Load saved preferences from SharedPreferences
  Future<void> _loadPreferences() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      // Load theme mode
      final themeModeIndex = prefs.getInt('themeMode') ?? 0;
      _themeMode = ThemeMode.values[themeModeIndex];
      
      // Load accessibility preferences
      _isLargeText = prefs.getBool('isLargeText') ?? false;
      _isHighContrast = prefs.getBool('isHighContrast') ?? false;
      
      // Load temperature unit preference
      _useCelsius = prefs.getBool('useCelsius') ?? true;
      
      notifyListeners();
    } catch (e) {
      debugPrint('Error loading preferences: $e');
    }
  }

  // Save preferences to SharedPreferences
  Future<void> _savePreferences() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      // Save theme mode
      await prefs.setInt('themeMode', _themeMode.index);
      
      // Save accessibility preferences
      await prefs.setBool('isLargeText', _isLargeText);
      await prefs.setBool('isHighContrast', _isHighContrast);
      
      // Save temperature unit preference
      await prefs.setBool('useCelsius', _useCelsius);
    } catch (e) {
      debugPrint('Error saving preferences: $e');
    }
  }

  void setThemeMode(ThemeMode mode) {
    _themeMode = mode;
    _savePreferences();
    notifyListeners();
  }

  void setLargeText(bool value) {
    _isLargeText = value;
    _savePreferences();
    notifyListeners();
  }

  void setHighContrast(bool value) {
    _isHighContrast = value;
    _savePreferences();
    notifyListeners();
  }

  void setUseCelsius(bool value) {
    _useCelsius = value;
    _savePreferences();
    notifyListeners();
  }
}
