import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:smart_weather/providers/theme_provider.dart';

class AccessibilitySettingsWidget extends StatelessWidget {
  const AccessibilitySettingsWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Settings',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          
          // Temperature Unit Section
          Text(
            'Temperature Unit',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 8),
          RadioListTile<bool>(
            title: const Text('Celsius (°C)'),
            value: true,
            groupValue: themeProvider.useCelsius,
            onChanged: (value) {
              if (value != null) {
                themeProvider.setUseCelsius(value);
              }
            },
          ),
          RadioListTile<bool>(
            title: const Text('Fahrenheit (°F)'),
            value: false,
            groupValue: themeProvider.useCelsius,
            onChanged: (value) {
              if (value != null) {
                themeProvider.setUseCelsius(value);
              }
            },
          ),
          
          const Divider(),
          
          // Theme Mode Section
          Text(
            'Theme',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 8),
          RadioListTile<ThemeMode>(
            title: const Text('System Default'),
            value: ThemeMode.system,
            groupValue: themeProvider.themeMode,
            onChanged: (ThemeMode? value) {
              if (value != null) {
                themeProvider.setThemeMode(value);
              }
            },
          ),
          RadioListTile<ThemeMode>(
            title: const Text('Light Mode'),
            value: ThemeMode.light,
            groupValue: themeProvider.themeMode,
            onChanged: (ThemeMode? value) {
              if (value != null) {
                themeProvider.setThemeMode(value);
              }
            },
          ),
          RadioListTile<ThemeMode>(
            title: const Text('Dark Mode'),
            value: ThemeMode.dark,
            groupValue: themeProvider.themeMode,
            onChanged: (ThemeMode? value) {
              if (value != null) {
                themeProvider.setThemeMode(value);
              }
            },
          ),
          
          const Divider(),
          
          // Accessibility Section
          Text(
            'Accessibility',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 8),
          
          // Text Size
          SwitchListTile(
            title: const Text('Large Text'),
            subtitle: const Text('Increase text size for better readability'),
            value: themeProvider.isLargeText,
            onChanged: (bool value) {
              themeProvider.setLargeText(value);
            },
          ),
          
          // High Contrast
          SwitchListTile(
            title: const Text('High Contrast'),
            subtitle: const Text('Enhance color contrast for better visibility'),
            value: themeProvider.isHighContrast,
            onChanged: (bool value) {
              themeProvider.setHighContrast(value);
            },
          ),
          
          const SizedBox(height: 16),
          
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              minimumSize: const Size(double.infinity, 50),
            ),
            child: const Text('Close Settings'),
          ),
        ],
      ),
    );
  }
}
