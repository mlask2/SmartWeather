import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:smart_weather/models/weather_model.dart';
import 'package:smart_weather/providers/theme_provider.dart';

class HourlyForecastWidget extends StatelessWidget {
  final List<HourlyForecastModel> forecast;

  const HourlyForecastWidget({
    super.key,
    required this.forecast,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '24-Hour Forecast',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
              semanticsLabel: 'Twenty Four Hour Forecast',
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 140,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: forecast.length,
                itemBuilder: (context, index) {
                  return _buildHourlyForecastItem(context, forecast[index]);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHourlyForecastItem(BuildContext context, HourlyForecastModel hour) {
    final theme = Theme.of(context);
    final themeProvider = Provider.of<ThemeProvider>(context);
    final isHighContrast = themeProvider.isHighContrast;
    final useCelsius = themeProvider.useCelsius;
    final time = DateTime.parse(hour.time);
    final formattedTime = DateFormat('ha').format(time);
    
    // Get temperature based on user preference
    final temp = useCelsius ? hour.tempC.round() : hour.tempF.round();
    final tempUnit = useCelsius ? '°C' : '°F';
    final windSpeed = useCelsius 
      ? '${hour.windKph.round()} km/h'
      : '${hour.windMph.round()} mph';
    
    return Semantics(
      label: 'Forecast for ${formattedTime}: $temp degrees ${useCelsius ? "Celsius" : "Fahrenheit"}, ${hour.condition.text}, ${hour.chanceOfRain}% chance of rain',
      child: Container(
        width: 80,
        margin: const EdgeInsets.only(right: 8),
        decoration: BoxDecoration(
          color: isHighContrast ? Colors.white : null,
          borderRadius: BorderRadius.circular(8),
          border: isHighContrast 
            ? Border.all(color: Colors.black, width: 1) 
            : null,
        ),
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              formattedTime,
              style: theme.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: isHighContrast ? Colors.black : null,
              ),
            ),
            Image.network(
              'https:${hour.condition.icon}',
              width: 40,
              height: 40,
              errorBuilder: (context, error, stackTrace) {
                return const Icon(Icons.image_not_supported, size: 40);
              },
              semanticLabel: hour.condition.text,
            ),
            Text(
              '$temp$tempUnit',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: isHighContrast ? Colors.black : null,
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.umbrella,
                  size: 12,
                  color: isHighContrast ? Colors.black : Colors.blue,
                ),
                const SizedBox(width: 2),
                Text(
                  '${hour.chanceOfRain}%',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: isHighContrast ? Colors.black : null,
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.air,
                  size: 12,
                  color: isHighContrast ? Colors.black : Colors.grey,
                ),
                const SizedBox(width: 2),
                Text(
                  windSpeed,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: isHighContrast ? Colors.black : null,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
