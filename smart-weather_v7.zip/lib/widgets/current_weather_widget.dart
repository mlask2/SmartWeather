import 'package:flutter/material.dart';
import 'package:smart_weather/models/weather_model.dart';
import 'package:provider/provider.dart';
import 'package:smart_weather/providers/theme_provider.dart';

class CurrentWeatherWidget extends StatelessWidget {
  final WeatherModel data;

  const CurrentWeatherWidget({
    super.key,
    required this.data,
  });

  @override
  Widget build(BuildContext context) {
    final current = data.current;
    final location = data.location;
    final theme = Theme.of(context);
    final themeProvider = Provider.of<ThemeProvider>(context);
    final isHighContrast = themeProvider.isHighContrast;
    final useCelsius = themeProvider.useCelsius;
    
    // Get the appropriate temperature based on user preference
    final mainTemp = useCelsius ? current.tempC.round() : current.tempF.round();
    final feelsLikeTemp = useCelsius ? current.feelslikeC.round() : current.feelslikeF.round();
    final tempUnit = useCelsius ? '°C' : '°F';
    
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    '${location.name}, ${location.country}',
                    style: theme.textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                    overflow: TextOverflow.ellipsis,
                    semanticsLabel: 'Location: ${location.name}, ${location.country}',
                  ),
                ),
                Image.network(
                  'https:${current.condition.icon}',
                  width: 64,
                  height: 64,
                  errorBuilder: (context, error, stackTrace) {
                    return const Icon(Icons.image_not_supported, size: 64);
                  },
                  semanticLabel: current.condition.text,
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Left column - Temperature and condition
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '$mainTemp$tempUnit',
                                  style: theme.textTheme.headlineMedium?.copyWith(
                                    fontWeight: FontWeight.bold,
                                    color: isHighContrast ? Colors.black : null,
                                  ),
                                  semanticsLabel: 'Temperature: $mainTemp degrees ${useCelsius ? "Celsius" : "Fahrenheit"}',
                                ),
                                Text(
                                  'Feels like: $feelsLikeTemp$tempUnit',
                                  style: theme.textTheme.bodyMedium?.copyWith(
                                    color: isHighContrast 
                                      ? Colors.black 
                                      : theme.colorScheme.onSurfaceVariant,
                                  ),
                                  semanticsLabel: 'Feels like: $feelsLikeTemp degrees ${useCelsius ? "Celsius" : "Fahrenheit"}',
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        current.condition.text,
                        style: theme.textTheme.titleMedium?.copyWith(
                          color: isHighContrast 
                            ? Colors.black 
                            : theme.colorScheme.onSurfaceVariant,
                        ),
                        semanticsLabel: 'Weather condition: ${current.condition.text}',
                      ),
                    ],
                  ),
                ),
                
                // Right column - Weather details
                Expanded(
                  child: Column(
                    children: [
                      _buildWeatherDetailRow(
                        context,
                        Icons.air,
                        'Wind',
                        useCelsius 
                          ? '${current.windKph.round()} km/h' 
                          : '${current.windMph.round()} mph',
                        semanticLabel: 'Wind speed: ${useCelsius ? "${current.windKph.round()} kilometers per hour" : "${current.windMph.round()} miles per hour"}',
                      ),
                      const SizedBox(height: 8),
                      _buildWeatherDetailRow(
                        context,
                        Icons.water_drop,
                        'Humidity',
                        '${current.humidity}%',
                        semanticLabel: 'Humidity: ${current.humidity} percent',
                      ),
                      const SizedBox(height: 8),
                      _buildWeatherDetailRow(
                        context,
                        Icons.umbrella,
                        'Precipitation',
                        useCelsius
                          ? '${current.precipMm} mm'
                          : '${current.precipIn.toStringAsFixed(2)} in',
                        semanticLabel: 'Precipitation: ${useCelsius ? "${current.precipMm} millimeters" : "${current.precipIn.toStringAsFixed(2)} inches"}',
                      ),
                      const SizedBox(height: 8),
                      _buildWeatherDetailRow(
                        context,
                        Icons.wb_sunny,
                        'UV Index',
                        '${current.uv}',
                        semanticLabel: 'UV Index: ${current.uv}',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWeatherDetailRow(
    BuildContext context,
    IconData icon,
    String label,
    String value, {
    required String semanticLabel,
  }) {
    final theme = Theme.of(context);
    final isHighContrast = Provider.of<ThemeProvider>(context).isHighContrast;
    
    return Semantics(
      label: semanticLabel,
      child: Row(
        children: [
          Icon(
            icon,
            size: 20,
            color: isHighContrast ? Colors.black : theme.colorScheme.primary,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: isHighContrast ? Colors.black : null,
                  ),
                ),
                Text(
                  value,
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: isHighContrast 
                      ? Colors.black 
                      : theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
