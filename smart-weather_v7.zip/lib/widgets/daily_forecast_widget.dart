import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:smart_weather/models/weather_model.dart';
import 'package:smart_weather/providers/theme_provider.dart';

class DailyForecastWidget extends StatelessWidget {
  final List<DailyForecastModel> forecast;

  const DailyForecastWidget({
    super.key,
    required this.forecast,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '7-Day Forecast',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
              semanticsLabel: 'Seven Day Forecast',
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 220,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: forecast.length,
                itemBuilder: (context, index) {
                  return _buildDailyForecastItem(context, forecast[index]);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDailyForecastItem(BuildContext context, DailyForecastModel day) {
    final theme = Theme.of(context);
    final themeProvider = Provider.of<ThemeProvider>(context);
    final isHighContrast = themeProvider.isHighContrast;
    final useCelsius = themeProvider.useCelsius;
    final date = DateTime.parse(day.date);
    final formattedDate = DateFormat('EEE, MMM d').format(date);
    
    // Get temperatures based on user preference
    final maxTemp = useCelsius ? day.day.maxtempC.round() : day.day.maxtempF.round();
    final minTemp = useCelsius ? day.day.mintempC.round() : day.day.mintempF.round();
    final tempUnit = useCelsius ? '°C' : '°F';
    final windSpeed = useCelsius 
      ? '${day.day.maxwindKph.round()} km/h'
      : '${day.day.maxwindMph.round()} mph';
    
    return Semantics(
      label: 'Forecast for ${formattedDate}: ${day.day.condition.text}, high of $maxTemp degrees ${useCelsius ? "Celsius" : "Fahrenheit"}, low of $minTemp degrees ${useCelsius ? "Celsius" : "Fahrenheit"}, ${day.day.dailyChanceOfRain}% chance of rain',
      child: Container(
        width: 140,
        margin: const EdgeInsets.only(right: 12),
        decoration: BoxDecoration(
          color: isHighContrast 
            ? Colors.white 
            : theme.colorScheme.surfaceVariant.withOpacity(0.3),
          borderRadius: BorderRadius.circular(12),
          border: isHighContrast 
            ? Border.all(color: Colors.black, width: 1) 
            : null,
        ),
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              formattedDate,
              style: theme.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.bold,
                color: isHighContrast ? Colors.black : null,
              ),
              textAlign: TextAlign.center,
            ),
            Image.network(
              'https:${day.day.condition.icon}',
              width: 48,
              height: 48,
              errorBuilder: (context, error, stackTrace) {
                return const Icon(Icons.image_not_supported, size: 48);
              },
              semanticLabel: day.day.condition.text,
            ),
            Text(
              day.day.condition.text,
              style: theme.textTheme.bodySmall?.copyWith(
                color: isHighContrast ? Colors.black : null,
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            _buildForecastDetail(
              context,
              Icons.thermostat,
              Colors.red,
              'High: $maxTemp$tempUnit',
            ),
            _buildForecastDetail(
              context,
              Icons.thermostat,
              Colors.blue,
              'Low: $minTemp$tempUnit',
            ),
            _buildForecastDetail(
              context,
              Icons.umbrella,
              Colors.blue,
              'Rain: ${day.day.dailyChanceOfRain}%',
            ),
            _buildForecastDetail(
              context,
              Icons.air,
              Colors.grey,
              'Wind: $windSpeed',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildForecastDetail(
    BuildContext context,
    IconData icon,
    Color color,
    String text,
  ) {
    final isHighContrast = Provider.of<ThemeProvider>(context).isHighContrast;
    
    return Row(
      children: [
        Icon(
          icon,
          size: 14,
          color: isHighContrast ? Colors.black : color,
        ),
        const SizedBox(width: 4),
        Expanded(
          child: Text(
            text,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: isHighContrast ? Colors.black : null,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }
}
