import 'dart:convert';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'package:smart_weather/models/weather_model.dart';

class WeatherService {
  final String _baseUrl = 'https://api.weatherapi.com/v1';
  String? _apiKey;
  
  // Cache for API responses
  final Map<String, _CachedResponse> _cache = {};
  
  // Cache expiration time (2 minutes)
  final Duration _cacheExpiration = const Duration(minutes: 2);

  WeatherService() {
    _apiKey = dotenv.env['WEATHER_API_KEY'];
  }

  bool get isApiKeyValid => _apiKey != null && _apiKey!.length > 10;

  Future<WeatherModel> getWeatherByCity(String city) async {
    if (!isApiKeyValid) {
      throw Exception('API key is missing or invalid');
    }

    final cacheKey = 'city:$city';
    
    // Check if we have a valid cached response
    if (_cache.containsKey(cacheKey) && !_cache[cacheKey]!.isExpired()) {
      return _cache[cacheKey]!.data;
    }

    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/forecast.json?key=$_apiKey&q=$city&days=7&aqi=no&alerts=no'),
        headers: {'Accept-Encoding': 'gzip, deflate'},
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final weatherData = WeatherModel.fromJson(json.decode(response.body));
        
        // Cache the response
        _cache[cacheKey] = _CachedResponse(weatherData);
        
        return weatherData;
      } else {
        final errorData = json.decode(response.body);
        if (response.statusCode == 401 || response.statusCode == 403) {
          throw Exception('Invalid API key. Please check your Weather API key.');
        }
        throw Exception(errorData['error']['message'] ?? 'Failed to fetch weather data');
      }
    } catch (e) {
      throw Exception('Error fetching weather data: $e');
    }
  }

  Future<WeatherModel> getWeatherByCoordinates(double lat, double lon) async {
    if (!isApiKeyValid) {
      throw Exception('API key is missing or invalid');
    }

    final cacheKey = 'coords:$lat,$lon';
    
    // Check if we have a valid cached response
    if (_cache.containsKey(cacheKey) && !_cache[cacheKey]!.isExpired()) {
      return _cache[cacheKey]!.data;
    }

    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/forecast.json?key=$_apiKey&q=$lat,$lon&days=7&aqi=no&alerts=no'),
        headers: {'Accept-Encoding': 'gzip, deflate'},
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final weatherData = WeatherModel.fromJson(json.decode(response.body));
        
        // Cache the response
        _cache[cacheKey] = _CachedResponse(weatherData);
        
        return weatherData;
      } else {
        final errorData = json.decode(response.body);
        if (response.statusCode == 401 || response.statusCode == 403) {
          throw Exception('Invalid API key. Please check your Weather API key.');
        }
        throw Exception(errorData['error']['message'] ?? 'Failed to fetch weather data');
      }
    } catch (e) {
      throw Exception('Error fetching weather data: $e');
    }
  }
  
  // Clear all cached data
  void clearCache() {
    _cache.clear();
  }
}

// Helper class for caching responses
class _CachedResponse {
  final WeatherModel data;
  final DateTime timestamp;
  final Duration validDuration;
  
  _CachedResponse(
    this.data, {
    this.validDuration = const Duration(minutes: 2),
  }) : timestamp = DateTime.now();
  
  bool isExpired() {
    final now = DateTime.now();
    return now.difference(timestamp) > validDuration;
  }
}
