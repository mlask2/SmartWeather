class WeatherModel {
  final LocationModel location;
  final CurrentWeatherModel current;
  final ForecastModel forecast;
  final List<HourlyForecastModel> hourly;

  WeatherModel({
    required this.location,
    required this.current,
    required this.forecast,
    required this.hourly,
  });

  factory WeatherModel.fromJson(Map<String, dynamic> json) {
    // Extract hourly forecast from the first day
    final List<HourlyForecastModel> hourlyList = [];
    if (json['forecast'] != null && 
        json['forecast']['forecastday'] != null && 
        json['forecast']['forecastday'].isNotEmpty) {
      final hourData = json['forecast']['forecastday'][0]['hour'];
      for (var hour in hourData) {
        hourlyList.add(HourlyForecastModel.fromJson(hour));
      }
    }

    return WeatherModel(
      location: LocationModel.fromJson(json['location']),
      current: CurrentWeatherModel.fromJson(json['current']),
      forecast: ForecastModel.fromJson(json['forecast']),
      hourly: hourlyList,
    );
  }

  // Create a mock weather model for testing or when API fails
  factory WeatherModel.mock(String locationName) {
    return WeatherModel(
      location: LocationModel(
        name: locationName,
        country: 'Demo Country',
        lat: 51.5074,
        lon: -0.1278,
      ),
      current: CurrentWeatherModel(
        tempC: 22,
        tempF: 71.6,
        condition: WeatherCondition(
          text: 'Partly cloudy',
          icon: '//cdn.weatherapi.com/weather/64x64/day/116.png',
          code: 1003,
        ),
        windKph: 15,
        windMph: 9.3,
        humidity: 65,
        precipMm: 0,
        precipIn: 0,
        feelslikeC: 22,
        feelslikeF: 71.6,
        uv: 4,
      ),
      forecast: ForecastModel(
        forecastday: List.generate(7, (index) {
          final date = DateTime.now().add(Duration(days: index));
          return DailyForecastModel(
            date: '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}',
            day: DayModel(
              maxtempC: 22 + (index % 5),
              maxtempF: 71.6 + (index % 9),
              mintempC: 15 + (index % 3),
              mintempF: 59 + (index % 5),
              avgtempC: 18 + (index % 4),
              avgtempF: 64.4 + (index % 7),
              condition: WeatherCondition(
                text: ['Sunny', 'Partly cloudy', 'Cloudy', 'Light rain'][index % 4],
                icon: '//cdn.weatherapi.com/weather/64x64/day/${[113, 116, 119, 296][index % 4]}.png',
                code: [1000, 1003, 1006, 1183][index % 4],
              ),
              dailyChanceOfRain: (index * 7) % 50,
              dailyChanceOfSnow: 0,
              maxwindKph: 10 + (index * 3) % 20,
              maxwindMph: 6 + (index * 2) % 12,
              totalprecipMm: (index * 0.7) % 5,
              totalprecipIn: (index * 0.03) % 0.2,
            ),
          );
        }),
      ),
      hourly: List.generate(24, (index) {
        final hour = DateTime.now().add(Duration(hours: index));
        return HourlyForecastModel(
          time: hour.toIso8601String(),
          tempC: 18 + (index % 8),
          tempF: 64.4 + (index % 14),
          condition: WeatherCondition(
            text: ['Clear', 'Partly cloudy', 'Cloudy', 'Light rain'][index % 4],
            icon: '//cdn.weatherapi.com/weather/64x64/night/${[113, 116, 119, 296][index % 4]}.png',
            code: [1000, 1003, 1006, 1183][index % 4],
          ),
          windKph: 5 + (index % 15),
          windMph: 3 + (index % 9),
          chanceOfRain: (index * 5) % 40,
          chanceOfSnow: 0,
        );
      }),
    );
  }
}

class LocationModel {
  final String name;
  final String country;
  final double lat;
  final double lon;

  LocationModel({
    required this.name,
    required this.country,
    required this.lat,
    required this.lon,
  });

  factory LocationModel.fromJson(Map<String, dynamic> json) {
    return LocationModel(
      name: json['name'],
      country: json['country'],
      lat: json['lat'].toDouble(),
      lon: json['lon'].toDouble(),
    );
  }
}

class CurrentWeatherModel {
  final double tempC;
  final double tempF;
  final WeatherCondition condition;
  final double windKph;
  final double windMph;
  final int humidity;
  final double precipMm;
  final double precipIn;
  final double feelslikeC;
  final double feelslikeF;
  final double uv;

  CurrentWeatherModel({
    required this.tempC,
    required this.tempF,
    required this.condition,
    required this.windKph,
    required this.windMph,
    required this.humidity,
    required this.precipMm,
    required this.precipIn,
    required this.feelslikeC,
    required this.feelslikeF,
    required this.uv,
  });

  factory CurrentWeatherModel.fromJson(Map<String, dynamic> json) {
    return CurrentWeatherModel(
      tempC: json['temp_c'].toDouble(),
      tempF: json['temp_f'].toDouble(),
      condition: WeatherCondition.fromJson(json['condition']),
      windKph: json['wind_kph'].toDouble(),
      windMph: json['wind_mph'].toDouble(),
      humidity: json['humidity'],
      precipMm: json['precip_mm'].toDouble(),
      precipIn: json['precip_in'].toDouble(),
      feelslikeC: json['feelslike_c'].toDouble(),
      feelslikeF: json['feelslike_f'].toDouble(),
      uv: json['uv'].toDouble(),
    );
  }
}

class WeatherCondition {
  final String text;
  final String icon;
  final int code;

  WeatherCondition({
    required this.text,
    required this.icon,
    required this.code,
  });

  factory WeatherCondition.fromJson(Map<String, dynamic> json) {
    return WeatherCondition(
      text: json['text'],
      icon: json['icon'],
      code: json['code'],
    );
  }
}

class ForecastModel {
  final List<DailyForecastModel> forecastday;

  ForecastModel({
    required this.forecastday,
  });

  factory ForecastModel.fromJson(Map<String, dynamic> json) {
    List<DailyForecastModel> forecastList = [];
    for (var day in json['forecastday']) {
      forecastList.add(DailyForecastModel.fromJson(day));
    }
    return ForecastModel(
      forecastday: forecastList,
    );
  }
}

class DailyForecastModel {
  final String date;
  final DayModel day;

  DailyForecastModel({
    required this.date,
    required this.day,
  });

  factory DailyForecastModel.fromJson(Map<String, dynamic> json) {
    return DailyForecastModel(
      date: json['date'],
      day: DayModel.fromJson(json['day']),
    );
  }
}

class DayModel {
  final double maxtempC;
  final double maxtempF;
  final double mintempC;
  final double mintempF;
  final double avgtempC;
  final double avgtempF;
  final WeatherCondition condition;
  final int dailyChanceOfRain;
  final int dailyChanceOfSnow;
  final double maxwindKph;
  final double maxwindMph;
  final double totalprecipMm;
  final double totalprecipIn;

  DayModel({
    required this.maxtempC,
    required this.maxtempF,
    required this.mintempC,
    required this.mintempF,
    required this.avgtempC,
    required this.avgtempF,
    required this.condition,
    required this.dailyChanceOfRain,
    required this.dailyChanceOfSnow,
    required this.maxwindKph,
    required this.maxwindMph,
    required this.totalprecipMm,
    required this.totalprecipIn,
  });

  factory DayModel.fromJson(Map<String, dynamic> json) {
    return DayModel(
      maxtempC: json['maxtemp_c'].toDouble(),
      maxtempF: json['maxtemp_f'].toDouble(),
      mintempC: json['mintemp_c'].toDouble(),
      mintempF: json['mintemp_f'].toDouble(),
      avgtempC: json['avgtemp_c'].toDouble(),
      avgtempF: json['avgtemp_f'].toDouble(),
      condition: WeatherCondition.fromJson(json['condition']),
      dailyChanceOfRain: json['daily_chance_of_rain'],
      dailyChanceOfSnow: json['daily_chance_of_snow'],
      maxwindKph: json['maxwind_kph'].toDouble(),
      maxwindMph: json['maxwind_mph'].toDouble(),
      totalprecipMm: json['totalprecip_mm'].toDouble(),
      totalprecipIn: json['totalprecip_in'].toDouble(),
    );
  }
}

class HourlyForecastModel {
  final String time;
  final double tempC;
  final double tempF;
  final WeatherCondition condition;
  final double windKph;
  final double windMph;
  final int chanceOfRain;
  final int chanceOfSnow;

  HourlyForecastModel({
    required this.time,
    required this.tempC,
    required this.tempF,
    required this.condition,
    required this.windKph,
    required this.windMph,
    required this.chanceOfRain,
    required this.chanceOfSnow,
  });

  factory HourlyForecastModel.fromJson(Map<String, dynamic> json) {
    return HourlyForecastModel(
      time: json['time'],
      tempC: json['temp_c'].toDouble(),
      tempF: json['temp_f'].toDouble(),
      condition: WeatherCondition.fromJson(json['condition']),
      windKph: json['wind_kph'].toDouble(),
      windMph: json['wind_mph'].toDouble(),
      chanceOfRain: json['chance_of_rain'],
      chanceOfSnow: json['chance_of_snow'],
    );
  }
}
