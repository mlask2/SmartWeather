import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { HourlyForecast } from "@/types/weather"
import { Wind, Umbrella } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"
import Image from "next/image"

interface HourlyForecastProps {
  forecast: HourlyForecast[]
}

export function HourlyForecastComponent({ forecast }: HourlyForecastProps) {
  const formatTime = (timeString: string) => {
    const date = new Date(timeString)
    return new Intl.DateTimeFormat("en-US", { hour: "numeric" }).format(date)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>24-Hour Forecast</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="w-full whitespace-nowrap">
          <div className="flex space-x-4 pb-4">
            {forecast.map((hour, index) => (
              <div key={index} className="flex flex-col items-center space-y-2 min-w-[80px]">
                <div className="text-sm font-medium">{formatTime(hour.time)}</div>
                <div>
                  {hour.condition.icon && (
                    <Image src={`https:${hour.condition.icon}`} alt={hour.condition.text} width={36} height={36} />
                  )}
                </div>
                <div className="text-sm">{Math.round(hour.temp_c)}°C</div>
                <div className="flex items-center gap-1">
                  <Umbrella className="h-4 w-4 text-blue-500" />
                  <span className="text-xs">{hour.chance_of_rain}%</span>
                </div>
                <div className="flex items-center gap-1">
                  <Wind className="h-4 w-4 text-gray-500" />
                  <span className="text-xs">{Math.round(hour.wind_kph)} km/h</span>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
