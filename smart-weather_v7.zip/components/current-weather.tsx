import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { WeatherData } from "@/types/weather"
import { Wind, Droplets, Umbrella, Sun } from "lucide-react"
import Image from "next/image"

interface CurrentWeatherProps {
  data: WeatherData
}

export function CurrentWeather({ data }: CurrentWeatherProps) {
  const { current, location } = data

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-2xl flex justify-between items-center">
          <div>
            {location.name}, {location.country}
          </div>
          <div className="flex items-center">
            {current.condition.icon && (
              <Image src={`https:${current.condition.icon}`} alt={current.condition.text} width={64} height={64} />
            )}
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex flex-col">
            <div className="text-4xl font-bold mb-2">
              {Math.round(current.temp_c)}°C / {Math.round(current.temp_f)}°F
            </div>
            <div className="text-lg text-muted-foreground capitalize">{current.condition.text}</div>
            <div className="text-sm text-muted-foreground mt-1">
              Feels like: {Math.round(current.feelslike_c)}°C / {Math.round(current.feelslike_f)}°F
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center gap-2">
              <Wind className="h-5 w-5 text-blue-500" />
              <div>
                <div className="text-sm font-medium">Wind</div>
                <div className="text-sm text-muted-foreground">
                  {Math.round(current.wind_kph)} km/h / {Math.round(current.wind_mph)} mph
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Droplets className="h-5 w-5 text-blue-500" />
              <div>
                <div className="text-sm font-medium">Humidity</div>
                <div className="text-sm text-muted-foreground">{current.humidity}%</div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Umbrella className="h-5 w-5 text-blue-500" />
              <div>
                <div className="text-sm font-medium">Precipitation</div>
                <div className="text-sm text-muted-foreground">
                  {current.precip_mm} mm / {current.precip_in.toFixed(2)} in
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Sun className="h-5 w-5 text-yellow-500" />
              <div>
                <div className="text-sm font-medium">UV Index</div>
                <div className="text-sm text-muted-foreground">{current.uv}</div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
